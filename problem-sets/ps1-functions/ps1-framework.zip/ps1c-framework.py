#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: flaherty
"""

def compute_rate(annual_salary):
    """Compute the savings rate needed"""
    
    # TODO: Implement me
    
    return rate, bisection_count
    

    
if __name__ == "__main__":
    annual_salary = int(input("Enter your starting annual salary: "))
    
    rate, bisection_count = compute_rate(annual_salary)
    if rate is None:
        print("It is not possible to pay the down payment in three years.")
    else:
        print("Minimal savings rate: %f" % rate)
        print("Steps in bisection search: %d" % bisection_count)
    
