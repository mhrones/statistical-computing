#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: flaherty (change me)
"""

def compute_months(annual_salary, portion_saved, total_cost):
    """Compute the number of months needed to save."""

    # TODO: Implement me
    return 0
    
    
if __name__ == "__main__":
    annual_salary = int(input("Enter your starting annual salary: "))
    # TODO: Implement me
    
    num_months = compute_months(annual_salary, portion_saved, total_cost)
    print("Number of months: %d" % num_months)
    
